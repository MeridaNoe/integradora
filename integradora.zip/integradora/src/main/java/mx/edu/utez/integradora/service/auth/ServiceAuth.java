package mx.edu.utez.integradora.service.auth;

import mx.edu.utez.integradora.model.auth.BeanAuth;
import mx.edu.utez.integradora.model.auth.DaoAuth;
import mx.edu.utez.integradora.model.usuario.BeanUsuario;
import mx.edu.utez.integradora.model.usuario.DaoUsuario;

import java.util.List;

public class ServiceAuth {
    DaoAuth daoAuth = new DaoAuth();
    DaoUsuario daoUsuario = new DaoUsuario();

    public BeanAuth login(String username, String password){
        return daoAuth.login(username, password);
    }

    public boolean verDocente(String nombre){return daoAuth.verDocente(nombre);}

    public BeanUsuario datosUsuario(int id){
        return daoUsuario.obtenerUnUsuario(id);
    }


}