package mx.edu.utez.integradora.model.auth;

import mx.edu.utez.integradora.model.usuario.DaoUsuario;
import mx.edu.utez.integradora.utils.MySQLConnection;

import java.sql.*;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoAuth {
    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;

    private final String GET_LOGIN = "SELECT * FROM usuario WHERE correo = ? AND contra = ?";

    private final String CREATE_USER = "INSERT INTO usuario (nombre, correo, telefono, contra, matricula, cuatrimestre, carrera, role)" +
            "VALUES (?,?,?,?,?,?,?,?)";

    private final String INSERT_USER = "INSERT INTO usuario ";

    private final String SELECT_DOCENTE = "SELECT * FROM usuario WHERE role = 'D'";

    private final String SELECT_ESTUDIANTE = "SELECT u.nombre, u.correo, u.telefono, u.carrera, a.estado FROM usuario u INNER JOIN asesoria a  WHERE u.role = 'E'";

    public BeanAuth login(String username, String password) {
        System.out.println("us "+username+" pas "+password);
        BeanAuth login = new BeanAuth();
        try {
            conn = new MySQLConnection().connect();
            String query = GET_LOGIN;
            pstm = conn.prepareStatement(query);
            pstm.setString(1, username);
            pstm.setString(2, password);
            rs = pstm.executeQuery();
            if (rs.next()) {
                login.setId(rs.getInt("id"));
                login.setNombre(rs.getString("nombre"));
                login.setCorreo(rs.getString("correo"));
                login.setTelefono(rs.getString("telefono"));
                login.setRol(rs.getString("role"));
                return login;
            } else {
                return null;
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoAuth.class.getName())
                    .log(Level.SEVERE, "Error en DaoAuth.login-> " + e);
            return null;
        } finally {
            closeConnections();
        }
    }

    public boolean create (BeanAuth user){
        try{
            conn = new MySQLConnection().connect();
            String query = CREATE_USER;
            pstm = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pstm.setString(1,user.getNombre());
            pstm.setString(2,user.getCorreo());
            pstm.setString(3,user.getTelefono());
            pstm.setString(4, user.getContra());
            pstm.setString(5, user.getMatricula());
            pstm.setInt(6,user.getCuatrimestre());
            pstm.setString(7, user.getCarrera());
            pstm.setString(8, user.getRol());
            if (pstm.executeUpdate()==1){
                ResultSet lastIdUsuario = pstm.getGeneratedKeys();
                if (lastIdUsuario.next()){
                    System.out.println(lastIdUsuario.getLong(1));
                    return user(user.getCorreo(),user.getContra(),user.getRol(), lastIdUsuario.getLong(1));
                }else {
                    return false;
                }
            }else{
                return false;
            }
        }catch (SQLException e){
                Logger.getLogger(DaoUsuario.class.getName())
                        .log(Level.SEVERE, "Error create -> ",e);
                return false;
        }finally {
            closeConnections();
        }
    }


    // QUE DIFERENCIA HAY ENTRE ESTOS DOS METODOS INSERT_USER Y CREATE_USER
    private boolean user(String correo, String contra, String rol, long user) {
        try {
            String query = INSERT_USER;
            pstm = conn.prepareStatement(query);
            pstm.setString(1, correo);
            pstm.setString(2, contra);
            pstm.setString(3, rol);
            pstm.setLong(4, user);

            return pstm.executeUpdate()==1;
        }catch (SQLException e){
            Logger.getLogger(DaoUsuario.class.getName())
                    .log(Level.SEVERE, "Error user -> ",e);
            return false;
        }
    }

    public boolean verDocente(String nombre){
        List<BeanAuth> docenteList =new LinkedList<>();
        BeanAuth docente = null;
        try {
            conn =  new MySQLConnection().connect();
            String query = SELECT_DOCENTE;
            pstm = conn.prepareStatement(query);
            pstm.setString(1, docente.getNombre());

            docenteList.add(docente);
        }catch (SQLException e) {
            Logger.getLogger(DaoAuth.class.getName())
                    .log(Level.SEVERE, "Error en DaoAuth.login-> " + e);
            return false;
        }
        return false;
    }

    public List<BeanAuth> verEstudiante(){
        List<BeanAuth> estudianteList = new LinkedList<>();
        BeanAuth estudiante = null;
        try {
conn= new MySQLConnection().connect();
String query =SELECT_ESTUDIANTE;
rs = pstm.executeQuery();
while (rs.next()){
    estudiante =new BeanAuth();
estudiante.getNombre();
estudiante.
}

        }catch (SQLException e){

        }
    }


    public void closeConnections() {
        try {
            if (conn != null) {
                conn.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}