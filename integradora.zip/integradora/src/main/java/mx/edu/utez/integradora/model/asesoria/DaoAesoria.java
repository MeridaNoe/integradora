package mx.edu.utez.integradora.model.asesoria;

import mx.edu.utez.integradora.model.asesoria.BeanAsesoria;
import mx.edu.utez.integradora.utils.MySQLConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoAesoria {

    Connection conn;
    PreparedStatement pstm;
    ResultSet rs;

    public final String GET_HISTORIAL = "select asesoria.materia, asesoria.docente_id, asesoria.estado, asesoria.mensaje, usuario.id from asesoria inner join usuario where usuario.id = ?;";


    public List<BeanAsesoria> Historial() {
        List<BeanAsesoria> historialList = new LinkedList<>();
        BeanAsesoria historial = null;
        try {
            conn = new MySQLConnection().connect();
            pstm = conn.prepareStatement(GET_HISTORIAL);
            rs = pstm.executeQuery();
            while (rs.next()) {
                historial = new BeanAsesoria();
                historial.getMateria();
                historial.getDocente_id();
                historial.getMensaje();
                historial.getEstado();

                historialList.add(historial);
            }
        } catch (SQLException e) {
            Logger.getLogger(DaoAesoria.class.getName())
                    .log(Level.SEVERE, "Error en getHistorial -> " + e);
        } finally {
            closeConnections();
        }
        return historialList;
    }


    public void closeConnections() {
        try {
            if (conn != null) {
                conn.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (rs != null) {
                rs.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }


    }
}