package mx.edu.utez.integradora.model.asesoria;

import java.sql.Connection;
import java.util.List;

public class DaoAesoria {
    public List<BeanAsesoria> obtenerAsesoria;

    Connection conn;














}
