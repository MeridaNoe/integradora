package mx.edu.utez.integradora.controller.peticion;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "ServletPeticion" ,
        urlPatterns = {
                "/getDocentes",
                "/getPetition",
                "/createPetition"





        })
public class ServletPeticion extends HttpServlet {

    String action;


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        action = request.getServletPath();

        switch (action){
            case "/createPetiton":
        }



    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
