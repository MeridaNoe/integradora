package mx.edu.utez.integradora.service.asesoria;

import mx.edu.utez.integradora.model.asesoria.BeanAsesoria;
import mx.edu.utez.integradora.model.asesoria.DaoAesoria;
import  mx.edu.utez.integradora.utils.ResultAction;
import java.util.List;

public class ServiceAsesoria {

    DaoAesoria daoAesoria = new DaoAesoria();


public List<BeanAsesoria> Historial() {
    return daoAesoria.Historial();
}



}
